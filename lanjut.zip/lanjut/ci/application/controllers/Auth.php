<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Auth extends CI_Controller
{

    public function __construct() //dipake vuar mmethod index dan register selalu pake ini
    {
        parent::__construct(); //manggil construct yang ada di CI_CONTROLLER
        $this->load->library('form_validation');
        $this->load->library('user_agent');
        $this->load->library('recaptcha');
        $this->load->library('Ciqrcode');
        $this->load->model('User_m');
        $this->load->library('phpmailer_lib');
        $this->load->database();
    }

    public function index()
    {
        //set rule untuk input di login
        $this->form_validation->set_rules('email', 'Email', 'required|trim|valid_email');
        $this->form_validation->set_rules('pass', 'Password', 'required|trim');



        if ($this->form_validation->run() == false) {
            $this->load->view('templates/header');
            $this->load->view('auth/login');
            $this->load->view('templates/footer');
        } else {
            $this->_login();
        }
    }

    public function QRcode($kodenya)

    {
        //QRcode dengan format gambar

        QRcode::png(
            $kodenya,
            $outfile = false,
            $level = QR_ECLEVEL_H,
            $size = 5,
            $margin = 1
        );
    }
    //function buat loginn
    private function _login()
    {
        $email = $this->input->post('email');
        $pass = $this->input->post('pass');


        //ambil data user 
        $user = $this->db->get_where('user', ['email' => $email])->row_array();


        //cek ada atau gak usernya
        if ($user) {
            if (password_verify($pass, $user['password'])) {
                //kalo ada ambil datanya
                $data = [
                    'email' => $user['email'],
                    'name' => $user['name']
                ];
                //data disimpen di session dan redirect ke halaman user
                $this->session->set_userdata($data);
                $captcha_answer = $this->input->post('g-recaptcha-response');
                $response = $this->recaptcha->verifyResponse($captcha_answer);

                if ($response['success']) {
                    // Code jika sukses
                    redirect(base_url('user/'));
                } else {
                    // Code jika gagal
                    $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">Recaptchanya goblok</div>');
                    redirect(base_url());
                }
            } else {
                $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">Incorrect password!</div>');
                redirect(base_url());
            }
        }
        //kalo gaada user di database (belom register)
        redirect(base_url());
    }

    //function buat register
    public function register()
    {
        //setting rule form untuk masing-masing input di register
        $this->form_validation->set_rules('name', 'Name', 'required|trim');
        $this->form_validation->set_rules('email', 'Email', 'required|trim|valid_email|is_unique[user.email]', [
            'is_unique' => 'Email already used'
        ]);
        $this->form_validation->set_rules('pass1', 'Password', 'required|trim|min_length[3]|matches[pass2]', [
            'matches' => 'password do not match',
            'min_length' => 'password too short'

        ]);
        $this->form_validation->set_rules('pass2', 'Password', 'required|trim|min_length[3]|matches[pass1]');

        //kalo salah reload page
        if ($this->form_validation->run() == false) {
            $this->load->view('templates/header');
            $this->load->view('auth/register');
            $this->load->view('templates/footer');
        } else {

            //kalo bener validasi form ambil data terus masukkin ke db dan redirect ke login page
            $data = [
                'name' => htmlspecialchars($this->input->post('name', true)),
                'email' => htmlspecialchars($this->input->post('email', true)),
                'password' => password_hash($this->input->post('pass1'), PASSWORD_DEFAULT),
            ];



            // PHPMailer object
            $mail = $this->phpmailer_lib->load();

            // SMTP configuration
            $mail->SMTPDebug = 1;
            $mail->isSMTP();
            $mail->Host       = 'smtp.gmail.com';
            $mail->SMTPAuth   = true;
            $mail->Username   = 'jjoni6377@gmail.com';
            $mail->Password   = 'jonojoni123';
            $mail->SMTPSecure = 'tls';
            $mail->Port       = 587;

            $mail->setFrom('jjoni6377@gmail.com', 'jono');
            $mail->addAddress($this->input->post('email'));
            $id = $this->input->post('email');
            $mail->isHTML(true);

            $mail->Subject = 'Registrasi lo slesai';
            $mail->Body    = ' <a href=' . base_url() . 'auth/verify/' . base64_encode($id) . '>Confirm</a>';


            // $mail->send();

            if (!$mail->send()) {
                echo "error";
            } else {
                echo "send";
            }

            $this->db->insert('user', $data);
            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Registrasi berhasil!</div>');
            redirect('auth');
        }
    }

    public function verify($id)
    {
        $id1 = base64_decode($id);
        $this->User_m->updateData($id1);
        $user = $this->User_m->updateData($id);
        if ($user == 'berhasil') {
            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Email berhasil di Confirm!</div>');
        } else {
            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Email belum berhasil di Confirm!</div>');
        }
        redirect('auth');
    }
}

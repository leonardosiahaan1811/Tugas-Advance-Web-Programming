<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Render extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->library('Ciqrcode');
        $this->load->library('Zend');
        $this->load->database();
    }

    public function index()
    {
        $data['title'] = "QRcode";
        $data['data'] = $this->db->get('user')->result();
        // echo "<pre>";
        //     print_r($data['data']);
        //     exit();
        // echo "</pre>";
        $this->load->view('render', $data);
    }

    public function QRcode($kodenya)
    {
        //QRcode dengan format gambar

        QRcode::png(
            $kodenya,
            $outfile = false,
            $level = QR_ECLEVEL_H,
            $size = 7,
            $margin = 1
        );
    }

    public function Barcode($kodenya)
    {
        $this->zend->load('Zend/Barcode');
        Zend_Barcode::render('code128', 'image', array('text' => $kodenya));
    }
}

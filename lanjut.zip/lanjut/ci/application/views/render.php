<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo $title  ?></title>
    <link rel="stylesheet" href="">
    <style>
        body {
            text-align: center;
        }
    </style>
</head>

<body>
    <h1 align="center"><?php echo $title ?></h1>

    <br>
    <table style="width:100%;" border="1">
        <tr>
            <th>Nama</th>
            <th>Email</th>
            <th>QRcode</th>

        </tr>
        <?php $no = 1;
        foreach ($data->result_array() as $row) {
            $no++;
            $email = $row['email'];
            ?>
            <tr>
                <td><?php echo $no ?></td>
                <td><?php echo $email ?></td>
                <td>
                    <img src="<?php echo site_url('auth/QRcode/' . $email); ?>" alt="">
                </td>
            </tr>
        <?php } ?>
    </table>
</body>

</html>
<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <ul class="navbar-nav bg-dark sidebar sidebar-dark accordion" id="accordionSidebar">

            <!-- Sidebar - Brand -->
            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="<?= base_url('user/'); ?>">
                <div class="sidebar-brand-icon rotate-n-15">
                    <i class="fas fa-laugh-wink"></i>
                </div>
                <div class="sidebar-brand-text mx-3">ANU & Leo </div>
            </a>

            <!-- Divider -->
            <hr class="sidebar-divider my-0">

            <!-- Divider -->
            <hr class="sidebar-divider">

            <!-- Nav Item - Tables -->
            <li class="nav-item">
                <a class="nav-link" href="<?= base_url('user/'); ?>">
                    <i class="fas fa-fw fa-table"></i>
                    <span>Tables</span></a>
            </li>

            <!-- Divider -->
            <hr class="sidebar-divider d-none d-md-block">

            <!-- Sidebar Toggler (Sidebar) -->
            <div class="text-center d-none d-md-inline">
                <button class="rounded-circle border-0" id="sidebarToggle"></button>
            </div>

        </ul>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

                    <!-- Sidebar Toggle (Topbar) -->
                    <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                        <i class="fa fa-bars"></i>
                    </button>


                    <!-- Topbar Navbar -->
                    <ul class="navbar-nav ml-auto">

                        <!-- Nav Item - User Information -->
                        <li class="nav-item dropdown no-arrow">
                            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <span class="mr-2 d-none d-lg-inline text-gray-600 small"><?= $user['name']; ?></span>
                                <img class="img-profile rounded-circle" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAAAh1BMVEX///8AAACNjY2GhoaSkpIMDAyWlpYfHx8JCQkQEBCOjo7f39+Kiorw8PD8/Pzz8/O+vr7S0tKoqKhzc3Pl5eVXV1fq6uqysrJnZ2cXFxd/f39RUVG/v7/IyMgqKirY2NgyMjI6OjpoaGhbW1ugoKCtra1AQEBHR0dSUlI2NjZ3d3ccHBwmJiaYem6xAAAJ3klEQVR4nO2de1/qPAzHqSiIyLgqgihXRfG8/9d3RJqm27ruYtJ2fvb763mYZ/RLtzZNk7TV8qL1YfrZE7eL5+Vo4KcFrBp2FkLT88p3g4gV3Yukvl58N4pS4xTfWfvId7vIdDACCtGb+W4ZkdoZgN/q+24bibJ68Ed/YVCNvYPb03Wn/ax/4Lt5BNJwDrLHotVWfdbx2zoC4TRx0j9+Ux8/+moZkYaKZBK/0DeC11DX6glNXpn9kcHmRmJ8pC9NzJ1bM62ho0xz++Zy6dl5qygFc+GT6eJcXnTdKFLtJMTIdDGSF9euW0WpdwkxNF79tODXRf+sD+I0Y5itk3oXhhvz1eUfMGturYRy0XHttk20aggbwvDVEDaE4ashbAjDV0PYEIavhrAhDF8NYUMYvhrChjB8NYQNYfhqCBvC8NUQNoThqyGsH2HUX80nb6Mx7Nv/NcLRXoA2nZ8Imj9FOLwScb2P/xbhRKS1Hyz+DOHw2QD4LXssRo0IBwszIKj2hMNbO2D9CV9zAIsTRmGmYCw1lOvxIIoG/cmxNOH68LQ9/9/77i20wOg1kmjBsONNGcJB50v/RY5hBfNtoV2beDzzqShhp5WcSoXoBpT59QKNSqVO3BUk3G1SgN96COaVVJZaOob0oRhhlgLJilLpBvP0tcHvCAPJilrBi2O6CKNsRcIwsk2glcYwWEgbKUh4PHUO7b32wSdny4sKDFLzE/VVgnACL/ILTqYhmDtd2Rbz1X1hwpM+dM7VxwE8p19WwmVRwsQ4pVKGprStraKelfCuIGEqM0ghmvMYXMpOeFWMcJ++9pbF7lwkhKa3TS5Y/GdFUTyl1qwo78YbRR8aVxJgLHnPiqIgNOdYhpIVRUB4Y34Qp4EMNQSERpNW5Ugrs2bY/5aHyYNgpLETXp3/ezBR5up05HjscUH4kvDGLp0mR7M/pZ1B3Kv1o7bDfmTvw/cU3lkLd5MIex9mydks4o3Q5DappLwH3h+hGBeGMGs9OR0v+xHd4/It87Fnfw9Bm/v5y3h1+NA++sXkOBg9pX6xh4PRUeGI8EP9xEP8fFeOCrXO2AwU/w7picgNYeydm6mdoGrP6TDdfZp2yY50Qpj40ghmkIdSZFJYGidDT3FXtAvCdFfBjmwFt/g0D1AkDAoHhMv0NdgsKe9tfBCFpJXLczBbmCYs2dDXUnQtrSIQaLHZvvaSHwq99BF/Hxq6EDuxpA0+0xjE9moFDqLBepIcfrYwF/ETmgdMebGkebpDgn3qn64TM7B8yfkJzfO6nNHKmW6Rav2ruS7lKLaVefkN+AnNVyv5OFR1vOxyKi864w+iL8L7vKaaVMjNrEd3nd9TX4RylC43XUystwQNcUa5jWpKmLe2xGKWDzUjVLNhnkELO9vnEk+1IsR9ybyFF1bsnNn3DylsGuudS5ptUJkrv6qoQjzaq3kF1odYjzK/IOVIJGT+s9AItXbn1lDDgKdaEbY6qsW5zrqEI8DajoAItfVhXkDSY00JtRVi3sIkHrtu/pvwntKW2pgUYpP3lzF/u7UdYRFi0Haenyf2nFrbERahtg42rq416bXIre0IjBBjYnNXX9uaEmp9k2OhzupKqM0ZOZFzh7oSttT+xyJn7+m9roSRSvMxFOLWNbMT2udD2cp/5qu8hNpM0Lb/ITzQZivPTijNYEPc3lnMhNoS0G6hwnrE7H22P6VyuZbh8+Qm1Iwyu4UKvmLjD2Hvw9Zw2RX7rPGanRDTmXrW0cbaifJneq/y/dKpcmu+SkGI46Q9xtPWifJ1rhSbJg2PjDhoEkI8m+Le9mcwnBoHjJ/BpOIRFpdAr4wZmYRQy0qz5lk92R7FaFz9CLLJ01M7yylGQ1jwrBTZicZIXzYREWKGndX7dvmr34a3lBMVYWsLiNaV1OpIF6JUUGSEKv1M2A+Cc57AS0aoLRbDOvGGjhCTIipN22wiJETXVFDnUFAS4jIjjJzOiygJ0ddfOnqFUaSE6NTIWSu6FC1hpIKG3M7qNtES4nI4YynjQcSEOGXkOYmdiZoQt4e9p5JJkROqhVQo4yk5oeUgQz+iJ1Rp6YHYpwyEajx1u9LNEgMhzvtBHKjNQaiCMxeUd60qDkL02oSwyGAhxHVUANUqeAgx1ov2vlXEQ6jc2+KN+MblxUSIfinvkyITIS6GK2UcUYqLECt7OXaPpsRGOAzlOWUjxEDinA1+bvER4njqt2AFIyE+p17nfUZCHE83HHcvKk5CTACzbg0zi5UQM8A8OhdZCbX9KH+1xlTtU9bb+zRtZCwMm9dIJel580vtmKcszD3x5T+V5iPfIgejNDy9irIsD2MNF2WCe1oNf7E/QjhleNlyg6/nrDWM4Zk+FlIwELCGgGCMt4fRRpqOzI7N4glE9JLBpxnhxVTCYHD3G1JyKL1j/hpMt3Bt28BAw17wCzOHHe8Ng2XMv0TFgx/cevrbTgaaH2HFP6dODRkc4qJSNI42Lo1wmIudzMRaclfFcO4Kgq1MNzYxLofF1tG8CM4wV9GSOKC62h6GjHNnr76e8nzl4PuU0e/MlIqXl+I/WQR8KMwmm6a+iIl7TFU/qLuIiQSheGe1NB6hmopDYzhJyGsuqgnY4XlJaULGAUdtDLkMrDcQVi8tmiPMwXbpbwfCnXYAG896qr9V93d6eElffelKQ6TfUXjRjhGyZ31SCwlbg09sBO2XvCxv9LfArWtII9RXjHRzRv+gHwJ1luP9Z5iCL2GZagOV6vaP6YPnelT3LigglLEL8kklmxNTfO5DCGAxs4EPzhmXZLZbqqqY8LBXknp2Hvt0Q10nDejO5AaBpciymjH0ofttBLCkeMwMMGMe5lecv6RVkKnAtG463IjX9nmpJOeMjFoonAJThs3zLd9q+TUeMpNUmBSvKQU+RB/HzIKtxruN4NaHGBeUiWQ9Bg6eFPdzRUvL++J0Qx2cPChZghmRcRBQPkS+r7BJ7XjzTVXgQ+TeFM2QCuJnS/tSrhJfoXRqWcjlxIQllLeIz7wDqn8r9Qv6O9JShSuyeNlUkJnHJAiMkWJYnoaRcIWbbORWFdar8pvkgcWhiUcbBPR8JimmKdD2Ii6BvZfl0Pa7CQNb0Yvh//Bjva4wlfkW4UlyucX+XeiEiJ8k5Xo0J82r98Odf6QfmvT7s0LX2gmkG/+HrF+kHagkxPWvWjXT7xVA5jGorSOKU+UdlJV+lGMgdRyk4uX2v8ecVelp+nF0it8jkGojoLFIqnuc3nWKanpcJP55L5SaOEqR9YzI0nIXLldCq9v8hhdUN5ziW3EZ9lMqyfvZ8dkaps5SLK9uwHxnRfOsM2mL6dmHb7ustGPtS2r/5r0uRWH1R3enj82i4Nhz293s2/Nfb7D+ByHKcbE9MS1eAAAAAElFTkSuQmCC">
                            </a>
                            <!-- Dropdown - User Information -->
                            <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">

                                <div class="dropdown-divider"></div>
                                <a class="dropdown-item" href="<?= base_url('#'); ?>" data-toggle="modal" data-target="#logoutModal">
                                    <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Logout
                                </a>
                            </div>
                        </li>

                    </ul>

                </nav>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <!-- TABLE -->
                <div class="container">

                    <form action="<?= base_url('user/add/') ?>" method="post">
                        <div class="form-group">
                            <label>Name</label>
                            <input type="text" class="form-control" id="name" name="name" value="<?= set_value('name') ?>" placeholder="Full Name">
                            <?php echo form_error('name', '<small class="text-danger pl-2">', '</small> '); ?>
                        </div>
                        <div class="form-group">
                            <label>Email</label>
                            <input type="email" class="form-control" id="email" name="email" value="<?= set_value('email') ?>" placeholder="Enter Your Email">
                            <?php echo form_error('email', '<small class="text-danger pl-2">', '</small> '); ?>
                        </div>
                        <div class="form-group">
                            <label>Password</label>
                            <input type="password" class="form-control" id="pass" name="pass" value="<?= set_value('pass') ?>" placeholder="Password">
                            <?php echo form_error('pass', '<small class="text-danger pl-2">', '</small> '); ?>
                        </div>
                        <button type="submit" name="update" class="btn btn-success" value="update">Add</button>
                    </form>


                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; Your Website 2019</span>
                    </div>
                </div>
            </footer>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                    <a class="btn btn-primary" href="<?= base_url(); ?>">Logout</a>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

</body>